# Tuna - Afine seu negócio

Aplicativo móvel desenvolvido para o Projeto Integrador VI-B (Turma MA - TAS8130 ), envolvendo os conhecimentos das disciplinas Ciência dos Dados e Programação para Dispositivos Móveis II

---

## Sumário

1. [Nome do projeto](#1-nome-do-projeto)
2. [Problema que resolve](#2-problema-que-resolve)
3. [Público-alvo](#3-público-alvo)
4. [Características do aplicativo](#4-características-do-aplicativo)
5. [Modelo ER do banco de dados local](#5-modelo-er-do-banco-de-dados-local)
6. [Wireframe das telas](#6-wireframe-das-telas)
7. [Geração do arquivo APK](#7-geração-do-arquivo-apk)
8. [Tecnologias, bibliotecas e linguagens](#8-tecnologias-bibliotecas-e-linguagens)
9. [Banco de dados local](#9-banco-de-dados-local)

---

## 1. Nome do projeto

**Tuna**

**Slogan:** *"Afine seu negócio."*

O nome vem de *tuning* (afinar). Assim como um músico afina o instrumento para soar no tom certo, o Tuna "afina" a presença digital e a gestão estratégica para que a empresa tome decisões mais precisas em seus negócios.

---

## 2. Problema que resolve

- Modelagem de estoque:

O estoque de instrumentos é caro, tem alto valor agregado e baixo giro. Errar na variedade dos produtos pode quebrar o caixa da loja. A coleta e análise de dados das grandes marcas do setor e redes sociais, identifica tendências de consumo, podendo resolver esse desafio e por consequência aumentar as vendas.

- Precificação de produtos:

Muitos clientes utilizam as lojas físicas apenas para testar os instrumentos e, posteriormente, finalizam a compra em grandes e-commerces que oferecem preços menores. O rastreamento dos preços de grandes e-commerces junto ao alerta ao lojista, auxiliarão quando o preço dele ficou fora da margem competitiva.

- Segmentação de clientes:

Existe uma dificuldade de saber em qual nível musical os clientes estão. Com base no histórico de compras de cada um, o Tuna traz um modelo que os classifica nos níveis “Iniciante”, “Intermediário” e “Profissional”, facilitando a correta recomendação dos produtos que poderão comprar no futuro.

---

## 3. Público-alvo

- **Lojistas e gestores de lojas de instrumentos musicais**


---

## 4. Características do aplicativo

### 4.1 Requisitos funcionais

| Código | Módulo | Descrição |
|---|---|---|
| RF01 | Meu estoque | O sistema deve obter automaticamente, quando houver internet, a lista de todos os produtos da loja e gravá-la no banco local, mantendo-a atualizada, também possibilitando a importação manual de dados |
| RF02 | Meu estoque | O sistema deve obter dados de tendências do mercado quando houver internet e gravá-los no banco local |
| RF03 | Meu estoque | O sistema deve exibir os resultados das análises dos cruzamentos de dados (loja x mercado), recomendando a inclusão de novos produtos, reposição e estratégia para conseguir vender produtos “encalhados” |
| RF04 | Meu preço | O sistema deve obter os preços praticados por grandes e-commerces quando houver internet e gravá-los no banco local |
| RF05 | Meu preço | O sistema deve comparar o preço de cada produto da loja com o preço dos e-commerces e alertar o lojista quando o produto estiver fora da margem competitiva |
| RF06 | Meu cliente | O sistema deve obter automaticamente, quando houver internet, a lista de clientes e o histórico de compras da loja e gravá-los no banco local, mantendo-os atualizados, também possibilitando a importação manual de dados |
| RF07 | Meu cliente | O sistema deve classificar os clientes em “Iniciante”, “Intermediário” e “Profissional” com base no histórico de compras e recomendar produtos adequados a cada nível |
| RF08 | Sobre | O sistema deve exibir uma tela com o nome completo de todos os integrantes do grupo |

### 4.2 Requisitos não funcionais

| Código | Categoria | Descrição |
|---|---|---|
| RNF01 | Disponibilidade offline | O aplicativo deve manter todas as funcionalidades de consulta, análise e recomendação disponíveis sem internet, usando os dados já gravados no banco SQLite local |
| RNF02 | Rastreabilidade | Os dados obtidos pela sincronização devem ser gravados com data e fonte, e a data da última atualização deve ser exibida na tela |
| RNF03 | Confiabilidade | Uma falha na sincronização não deve apagar nem corromper os dados já salvos no banco local |
| RNF04 | Usabilidade | A interface deve ser simples e objetiva, permitindo ao lojista consultar indicadores e recomendações com poucos toques |
| RNF05 | Portabilidade | O aplicativo deve ser desenvolvido em Ionic/Angular e empacotado para Android com Capacitor |

---

## 5. Modelo ER do banco de dados local

<img width="1116" height="1048" alt="Untitled" src="https://github.com/user-attachments/assets/7eacb1c3-04f2-42c7-904f-d12fa6f9eab2" />

O banco de dados local (SQLite) possui as seguintes entidades principais:
* **produto:** Armazena o catálogo de itens da loja para funcionamento offline.
* **tendencia:** Guarda dados de mercado (categorias e marcas) para análises e recomendações.
* **preco_concorrente:** Registra os preços de e-commerces para comparar com os produtos da loja.
* **cliente:** Cadastro dos clientes com sua respectiva classificação de nível.
* **venda / item_venda:** Histórico de compras para rastreabilidade.
* **sync_log:** Registro de auditoria das sincronizações com a nuvem.

**Código fonte do diagrama (DBML):**

```sql
Table produto {
  id integer [pk, increment]
  codigo text [not null, unique]
  nome text [not null]
  categoria text [not null]
  marca text
  preco real [not null]
  quantidade integer [not null, default: 0]
  data_atualizacao text [not null]
}

Table tendencia {
  id integer [pk, increment]
  categoria text [not null]
  marca text
  indice_popularidade real [not null]
  fonte text [not null]
  data_coleta text [not null]
}

Table preco_concorrente {
  id integer [pk, increment]
  produto_id integer [not null]
  concorrente text [not null]
  preco real [not null]
  fonte text [not null]
  data_coleta text [not null]
}

Table cliente {
  id integer [pk, increment]
  nome text [not null]
  telefone text [unique]
  email text
  nivel text [note: 'Iniciante, Intermediário ou Profissional']
  data_atualizacao text [not null]
}

Table venda {
  id integer [pk, increment]
  cliente_id integer [not null]
  data_venda text [not null]
  total real [not null]
}

Table item_venda {
  id integer [pk, increment]
  venda_id integer [not null]
  produto_id integer [not null]
  quantidade integer [not null]
  preco_unitario real [not null]
}

Table sync_log {
  id integer [pk, increment]
  tipo text [not null]
  data_sync text [not null]
  status text [not null]
  registros integer [not null, default: 0]
}

Ref: preco_concorrente.produto_id > produto.id
Ref: venda.cliente_id > cliente.id
Ref: item_venda.venda_id > venda.id
Ref: item_venda.produto_id > produto.id
```

---

## 6. Wireframe das telas

  ### 6.1 Tela principal (splash)

**Objetivo:** apresentar a marca e iniciar a sincronização dos dados.

**Elementos principais:**
- Selo "Offline-first", logo, nome e slogan do Tuna;
- Botão "Abrir", que leva à tela Home;
- Mensagem informando que os dados ficam disponíveis mesmo sem internet.

**Requisitos atendidos:** RF01, RF02, RF04, RF06 (sincronização quando há internet) e RNF01.

**Dados utilizados:** `sync_log` (data e resultado da última sincronização).

<p align="center">
<img width="278" height="490" alt="PRINCIPAL" src="https://github.com/user-attachments/assets/be23db72-b245-470b-9ccd-087728a97cdc" />
</p>

---

### 6.2 Home

**Objetivo:** dar ao lojista uma visão geral dos três módulos do app.

**Elementos principais:**
- Saudação e data da última atualização dos dados;
- Sino de alertas;
- Um card-resumo por módulo (Meu estoque, Meu preço e Meu cliente), com acesso à tela correspondente;
- Barra de navegação inferior (Início, Meu estoque, Meu preço, Meu cliente e Sobre).

**Requisitos atendidos:** RF03, RF05, RF07 (resumos) e RNF02 (data da atualização).

**Dados utilizados:** consultas de resumo em `produto`, `preco_concorrente`, `cliente` e `sync_log`.

<p align="center">
<img width="288" height="476" alt="HOME" src="https://github.com/user-attachments/assets/01e8f1af-fe1a-41ec-a599-0642531f8ef4" />
</p>

---

### 6.3 Meu estoque

**Objetivo:** mostrar o cruzamento entre os produtos da loja e as tendências do mercado.

**Elementos principais:**
- Indicadores de produtos em alta, encalhados e para repor;
- Gráfico de rosca com os produtos por situação;
- Lista de recomendações (reposição e estratégia para produtos encalhados);
- Lista de oportunidades (produtos em alta que a loja ainda não possui).

**Requisitos atendidos:** RF03, RNF01 e RNF02.

**Dados utilizados:** `produto`, `item_venda`, `venda` e `tendencia`.

<p align="center">
<img width="266" height="478" alt="ESTOQUE" src="https://github.com/user-attachments/assets/432af597-d056-4719-a7df-75939aad079e" />
</p>

---

### 6.4 Meu preço

**Objetivo:** comparar os preços da loja com os praticados pelos grandes e-commerces.

**Elementos principais:**
- Indicadores de produtos fora e dentro da margem e diferença média;
- Gráfico de barras com a diferença percentual por produto e a linha da margem competitiva;
- Alertas de preço com o valor da loja, o valor do mercado, o e-commerce de origem e a evolução da diferença.

**Requisitos atendidos:** RF05, RNF01 e RNF02.

**Dados utilizados:** `produto` e `preco_concorrente`.

<p align="center">
<img width="262" height="482" alt="PREÇO" src="https://github.com/user-attachments/assets/7d29a589-65b2-47e6-9a00-1b23aec11708" />
</p>

---

### 6.5 Meu cliente

**Objetivo:** apresentar a classificação dos clientes e recomendar produtos adequados a cada nível.

**Elementos principais:**
- Indicadores de clientes por nível (Iniciante, Intermediário e Profissional);
- Gráfico combinado com o total de clientes e os clientes ativos por nível;
- Lista de clientes com nível, data da última compra e sugestão de produto.

**Requisitos atendidos:** RF06, RF07 e RNF01.

**Dados utilizados:** `cliente`, `venda`, `item_venda` e `produto`.


<p align="center">
<img width="272" height="479" alt="CLIENTE" src="https://github.com/user-attachments/assets/78dcf4c1-a1b4-4a59-bd43-ca892602a178" />
</p>

---

### 6.6 Sobre

**Objetivo:** identificar o aplicativo e os integrantes do grupo.

**Elementos principais:**
- Lista numerada com o nome completo de todos os integrantes;
- Logo, nome e slogan do Tuna.

**Requisitos atendidos:** RF08.

<p align="center">
<img width="269" height="492" alt="SOBRE" src="https://github.com/user-attachments/assets/83eb7e9b-f64f-4446-a51b-af4ffb255457" />
</p>

---

### 6.7 Diagrama de navegação (visão geral)

**Objetivo:** apresentar em uma única imagem todas as telas do Tuna e como o usuário navega entre elas.

**Como ler o diagrama:**
- Cada retângulo é uma tela do aplicativo, e as setas tracejadas indicam o caminho de navegação;
- A linha de cima reúne a **Tela principal**, a **Home** e a tela **Sobre**; a linha de baixo reúne as telas dos três módulos de análise: **Meu estoque**, **Meu preço** e **Meu cliente**.

**Fluxo de navegação:**
1. Ao abrir o aplicativo, o usuário vê a **Tela principal** (splash) e toca em "Abrir" para chegar à **Home**;
2. Da **Home**, ele acessa os módulos **Meu estoque**, **Meu preço** e **Meu cliente**, pelos cards-resumo ou pela barra de navegação inferior;
3. A tela **Sobre**, com a identificação do grupo, também é acessada pela barra de navegação inferior.

**Navegação entre telas:**
- Todas as telas, exceto a principal, compartilham a mesma **barra de navegação inferior** (Início, Meu estoque, Meu preço, Meu cliente e Sobre), que permite ir de qualquer tela para outra diretamente;
- O item da tela atual aparece destacado na barra, e por isso o aplicativo não usa botão de voltar;
- Para simplificar o diagrama, as setas mostram apenas o fluxo principal a partir da Home, e a navegação direta pela barra não foi desenhada entre todas as telas.

**Requisitos atendidos:** RNF04 (interface simples e objetiva) e RF08 (acesso à tela Sobre).

<p align="center">
<img width="421" height="496" alt="WIREFRAMES - DIAGRAMA" src="https://github.com/user-attachments/assets/d56f60f2-5ffd-4946-9485-c3a0f9477bec" />
</p>

---

## 7. Geração do arquivo APK

O aplicativo Tuna será desenvolvido utilizando Ionic com Angular e TypeScript, juntamente com o Capacitor, responsável por integrar a aplicação ao ambiente nativo Android. Para gerar o arquivo APK, será utilizado o Android Studio, que permitirá realizar a compilação do projeto e disponibilizar o aplicativo para instalação em dispositivos compatíveis.

---

### 7.1. Ferramentas necessárias

Para realizar a geração do APK, serão utilizadas as seguintes ferramentas:

- **Node.js e npm:** necessários para executar os comandos do projeto e gerenciar suas dependências.
- **Ionic CLI:** utilizado para executar os comandos de compilação da aplicação desenvolvida com Ionic e Angular.
- **Capacitor:** responsável por integrar a aplicação web ao ambiente nativo Android.
- **Android Studio:** utilizado para abrir o projeto Android, configurar a compilação e gerar o arquivo APK.
- **Android SDK:** conjunto de ferramentas necessário para compilar e executar aplicativos Android.

---  

### 7.2. Etapas para geração do APK

A geração do arquivo APK seguirá as etapas descritas abaixo:

**1. Preparação do ambiente**

Inicialmente, será necessário instalar as ferramentas de desenvolvimento, obter o código-fonte do projeto e instalar suas dependências. Após abrir o terminal na pasta raiz do projeto, será executado o comando:

```bash
npm install
```

Também será necessário garantir que o Ionic CLI e as ferramentas do Android estejam instalados e configurados corretamente.

<br>

**2. Compilação da aplicação**

Será executado o comando abaixo para compilar a aplicação Ionic com Angular:

```bash
ionic build
```

Esse procedimento gera os arquivos da aplicação web que serão utilizados na versão móvel.

<br>

**3. Configuração e sincronização com o Capacitor**

Caso a plataforma Android ainda não tenha sido adicionada ao projeto, será necessário realizar essa configuração inicialmente:

```bash
npx cap add android
```

Após a preparação da plataforma Android e a compilação da aplicação, será executado o seguinte comando:

```bash
npx cap sync android
```

Essa etapa copia os arquivos compilados da aplicação e sincroniza as configurações e os plugins necessários com o projeto nativo Android.

<br>

**4. Abertura do projeto Android**

Em seguida, o projeto será aberto no Android Studio por meio do comando:

```bash
npx cap open android
```

No Android Studio, será realizada a verificação da configuração do projeto, do Android SDK e de suas dependências antes da compilação.

<br>

**5. Geração do arquivo APK**

No Android Studio, será possível gerar o arquivo APK pelo menu Build. Para uma versão de testes, poderá ser utilizada a opção Build Bundle(s) / APK(s) > Build APK(s).

Para uma versão de distribuição, deverá ser utilizada a opção Generate Signed Bundle / APK, selecionando APK e configurando a assinatura digital necessária para gerar uma versão assinada do aplicativo.

<br>

**6. Localização do arquivo gerado**

Após a conclusão bem-sucedida da compilação, o arquivo APK poderá ser localizado dentro da estrutura do projeto Android, normalmente no diretório:
`android/app/build/outputs/apk/`

Os arquivos poderão estar organizados em subdiretórios, como debug ou release, dependendo do tipo de compilação realizada.

O APK gerado poderá ser transferido para um dispositivo Android compatível para instalação e realização de testes.

---

**7.3. Considerações finais**

A utilização do Ionic, Angular e TypeScript, em conjunto com o Capacitor e o Android Studio, permitirá transformar o código-fonte do Tuna em um aplicativo instalável em dispositivos Android.

Após a geração do APK, serão realizados testes para verificar o funcionamento das telas, a navegação e as funcionalidades implementadas, incluindo o acesso aos dados armazenados localmente no banco SQLite.

A geração de uma versão assinada será necessária para a distribuição da versão de lançamento. As chaves e credenciais utilizadas na assinatura deverão ser armazenadas de forma segura, sem serem publicadas no repositório do projeto.

---

**7.4. Referências**

- [Ionic Framework – Desenvolvimento de aplicativos para Android](https://ionicframework.com/docs/developing/android)

- [Ionic Framework – Implantação de aplicativos móveis com Angular](https://ionicframework.com/docs/angular/your-first-app/deploying-mobile)

- [Capacitor – Configuração do ambiente de desenvolvimento](https://capacitorjs.com/docs/getting-started/environment-setup)

- [Android Developers – Preparação e geração do aplicativo para distribuição](https://developer.android.com/build/build-for-release)

- [Android Developers – Assinatura de aplicativos Android](https://developer.android.com/studio/publish/app-signing)

---

## 8. Tecnologias, bibliotecas e linguagens

O aplicativo Tuna será construído com as tecnologias listadas abaixo.

---

### 8.1. Linguagens de programação

| Linguagem | Uso no Tuna | Link |
|---|---|---|
| **TypeScript** | Linguagem principal do aplicativo (telas, serviços, sincronização e regras de análise) | [typescriptlang.org](https://www.typescriptlang.org) |
| **HTML5** | Estrutura das telas | [developer.mozilla.org](https://developer.mozilla.org/pt-BR/docs/Web/HTML) |
| **SCSS / CSS3** | Estilização das telas | [sass-lang.com](https://sass-lang.com) |
| **SQL (SQLite)** | Criação das tabelas e consultas do banco de dados local | [sqlite.org/lang](https://www.sqlite.org/lang.html) |

---

### 8.2. Frameworks

| Framework | Uso no Tuna | Link |
|---|---|---|
| **Ionic Framework** | Componentes de interface mobile (cards, listas, barra de navegação inferior) | [ionicframework.com](https://ionicframework.com) |
| **Angular** | Estrutura da aplicação (páginas, rotas e serviços) | [angular.dev](https://angular.dev) |
| **Capacitor** | Integração com o Android nativo e geração do projeto para o APK | [capacitorjs.com](https://capacitorjs.com) |

---

### 8.3. Banco de dados local

| Tecnologia | Uso no Tuna | Link |
|---|---|---|
| **SQLite** | Banco de dados local, no próprio celular, que mantém o app funcionando sem internet | [sqlite.org](https://www.sqlite.org) |
| **@capacitor-community/sqlite** | Plugin que conecta o aplicativo ao banco SQLite | [github.com/capacitor-community/sqlite](https://github.com/capacitor-community/sqlite) |

---

### 8.4. Bibliotecas

| Biblioteca | Uso no Tuna | Link |
|---|---|---|
| **Angular HttpClient** | Obtenção dos dados da loja, tendências e preços dos e-commerces quando houver internet (RF01, RF02, RF04 e RF06) | [angular.dev/guide/http](https://angular.dev/guide/http) |
| **@capacitor/network** | Verificação da conexão com a internet para iniciar a sincronização | [capacitorjs.com/docs/apis/network](https://capacitorjs.com/docs/apis/network) |
| **Chart.js** | Gráficos das telas Meu estoque, Meu preço e Meu cliente | [chartjs.org](https://www.chartjs.org) |

---

### 8.5. Ferramentas de desenvolvimento

| Ferramenta | Uso no Tuna | Link |
|---|---|---|
| **Node.js e npm** | Execução do projeto e gerenciamento das dependências | [nodejs.org](https://nodejs.org) |
| **Ionic CLI** | Criação, execução e compilação do projeto | [ionicframework.com/docs/cli](https://ionicframework.com/docs/cli) |
| **Android Studio e Android SDK** | Emulador e geração do arquivo APK | [developer.android.com/studio](https://developer.android.com/studio) |
| **Visual Studio Code** | Editor de código | [code.visualstudio.com](https://code.visualstudio.com) |
| **dbdiagram.io (DBML)** | Modelagem do diagrama ER do banco de dados | [dbdiagram.io](https://dbdiagram.io) |
| **Git e GitHub** | Controle de versão e repositório do projeto | [github.com](https://github.com) |

---

### 8.6. Instalação das dependências

```bash
npm install -g @ionic/cli
npm install @capacitor-community/sqlite @capacitor/network chart.js
```



---

### 9. Banco de dados local

Para armazenar os dados do aplicativo Tuna, será utilizado o SQLite, que permite salvar informações diretamente no dispositivo. Dessa forma, o usuário poderá consultar os dados mesmo quando não tiver acesso à internet.

A implementação será realizada utilizando Ionic com Angular e Capacitor. Para conectar o aplicativo ao banco de dados, será utilizada a biblioteca `@capacitor-community/sqlite`.

### 9.1. Organização das tabelas

O banco de dados será dividido em tabelas para facilitar o armazenamento e a consulta das informações:

- **produto:** armazenará os produtos cadastrados, como código, nome, categoria, marca, preço e quantidade em estoque.
- **tendencia:** guardará informações sobre tendências de mercado, incluindo categoria, marca, índice de popularidade, fonte e data da coleta.
- **preco_concorrente:** armazenará os preços encontrados nos concorrentes, relacionando cada preço ao produto correspondente.
- **cliente:** terá os dados dos clientes, como nome, telefone, e-mail e nível de classificação.
- **venda:** registrará as vendas realizadas, com a data e o valor total.
- **item_venda:** armazenará os produtos e as quantidades de cada venda.
- **sync_log:** guardará o histórico das sincronizações, incluindo data, situação e quantidade de registros atualizados.

### 9.2. Como será feita a sincronização

Quando o dispositivo estiver conectado à internet, o aplicativo poderá buscar informações atualizadas, como produtos, tendências, preços dos concorrentes e dados dos clientes.

Depois de receber essas informações, o aplicativo fará a validação e salvará os dados no SQLite. Assim, as informações continuarão disponíveis para consulta mesmo quando o usuário estiver offline.

Caso aconteça algum erro durante a sincronização, os dados que já estão salvos no dispositivo deverão ser preservados. Para isso, serão utilizadas transações no banco de dados. Se tudo ocorrer corretamente, as alterações serão confirmadas; caso contrário, serão canceladas.

Também será registrado o histórico de cada sincronização, permitindo consultar quando ela aconteceu e se foi concluída com sucesso. O aplicativo deverá mostrar a data da última atualização dos dados.

### 9.3. Utilização dos dados no aplicativo

As informações armazenadas serão utilizadas nas principais funcionalidades do Tuna:

- **Meu Estoque:** permitirá consultar os produtos, suas quantidades e informações relacionadas às tendências.
- **Meu Preço:** utilizará os preços dos produtos e dos concorrentes para facilitar a comparação.
- **Meu Cliente:** permitirá consultar os clientes e seu histórico de compras, ajudando na classificação e na identificação de produtos que podem ser interessantes para cada cliente.













